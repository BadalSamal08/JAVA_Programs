import java.util.*;
abstract class Shape
{
	double dimone,dimtwo;
	abstract void area();
}
class Triangle extends Shape
{
	double base,height,area;
	Triangle(double bs,double ht)
	{
		super.dimone=bs;
		super.dimtwo=ht;
	}
	void area()
	{
		System.out.println("Area of triangle="+(0.5*dimone*dimtwo));
	}
}
class Rectangle extends Shape
{
	double length,breadth;
	Rectangle(double len,double brdth)
	{
		length=len;
		breadth=brdth;
	}
	void area()
	{
		System.out.println("Area of rectangle="+(length*breadth));
	}
}
class Findarea
{
	public static void main(String Args[])
	{
		Shape s1;
		s1=new Triangle(4,8);
		s1.area();
		s1=new Rectangle(8,9.2);
		s1.area();
	}
}
