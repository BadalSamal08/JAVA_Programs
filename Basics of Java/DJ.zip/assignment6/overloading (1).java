class Shapeo
{
	double length,breadth;
	int base,height;
	Shapeo()
	{
		length=0;
		breadth=0;
		base=0;
		height=0;
	}
	void area(double len,double brdth)
	{
		length=len;
		breadth=brdth;
		System.out.println("Area of rectangle="+(length*breadth));
	}

	void area(int bs,int ht)
	{
		base=bs;
		height=ht;
		System.out.println("Area of triangle="+(0.5*base*height));		
	}
}
class Test
{
	public static void main(String Args[])
	{
		Shapeo s1=new Shapeo();
		s1.area(4,6);
		s1.area(3.2,3.0);
	}
}
