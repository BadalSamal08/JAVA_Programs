package btech.arithmetic;
public class MyMath
{
int op1,op2,op3;
	public MyMath(int a,int b)
	{
		op1=a;
		op2=b;
	}
	public void add()
	{
		System.out.println(op3=op1+op2);
	}
	public void sub()
	{
		System.out.println(op3=op1-op2);
	}
	public void mul()
	{
		System.out.println(op3=op1*op2);
	}
	public void div()
	{
		System.out.println(op3=op1/op2);
	}
}
