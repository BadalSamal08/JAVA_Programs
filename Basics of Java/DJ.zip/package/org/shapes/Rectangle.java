package org.shapes;
public class Rectangle
{
	int dimOne,dimTwo;
	Rectangle(int a,int b)
	{
		dimOne=a;
		dimTwo=b;
	}
	void computeArea()
	{
		System.out.println("Area of rectangle:"+dimOne*dimTwo);
	}
}
public class Circle
{
	int radius;
	Circle(int a)
	{
		radius=a;
	}
	void computeArea()
	{
		System.out.println("Area of rectangle:"+3.14*radius*radius);
	}
}
class square
{
	int dimOne,dimTwo;
	square(int a,int b)
	{
		dimOne=a;
		dimTwo=b;
	}
	void computeArea()
	{
		System.out.println("Area of rectangle:"+dimOne*dimTwo);
	}
}
class triangle
{
	int dimOne,dimTwo;
	triangle(int a,int b)
	{
		dimOne=a;
		dimTwo=b;
	}
	void computeArea()
	{
		System.out.println("Area of rectangle:"+0.5*dimOne*dimTwo);
	}
}