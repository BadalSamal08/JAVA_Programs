import btech.arithmetic.*;
class Test
{
	public static void main(String args[])
	{
		MyMath mn=new MyMath(50,5);
		mn.add();
		mn.sub();
		mn.div();
		mn.mul();
	}
}