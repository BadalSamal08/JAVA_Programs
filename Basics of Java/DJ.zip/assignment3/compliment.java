import java.util.*;
class compliment
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int a[]=new int[10],num,i;
		System.out.println("Enter the number of elements:");
		num=sc.nextInt();
		for( i=0;i<num;i++)
		{
			System.out.print("Enter the element:");
			a[i]=sc.nextInt();
		}
		for( i=0;i<num;i++)
		{
			if(a[i]==0)
				a[i]=1;
			else if(a[i]==1)
				a[i]=0;
		}
		for( i=0;i<num;i++)
		{
			System.out.print(a[i]);
		}
	}
}