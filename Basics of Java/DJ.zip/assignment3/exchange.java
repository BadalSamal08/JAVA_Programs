import java.util.*;
class exchange
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int a[]=new int[10];
		int b[]=new int[10],i,num,temp;
		System.out.print("Enter the number of elements:");
		num=sc.nextInt();
		for( i=0;i<num;i++)
		{
			System.out.print("Enter the element:");
			a[i]=sc.nextInt();
		}
		for( i=0;i<num;i++)
		{
			System.out.print("Enter the element:");
			b[i]=sc.nextInt();
		}
		if(num>=3)
		{
			for( i=num-3;i<num;i++)
		{
			temp=a[i];
			a[i]=b[i];
			b[i]=temp;
		}
		}
		for( i=0;i<num;i++)
			System.out.print(a[i]+" ");
		System.out.println();
		for( i=0;i<num;i++)
			System.out.print(b[i]+" ");
	}
}