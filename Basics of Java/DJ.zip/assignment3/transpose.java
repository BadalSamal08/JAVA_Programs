import java.util.*;
class transpose
{
	public static void main(String args[])
	{
		Scanner sc= new Scanner(System.in);
		int a[][]=new int[10][10],rows,col;
		System.out.print("Enter the number of rows and coloumns:");
		rows=sc.nextInt();
		col=sc.nextInt();
		input(a,rows,col);
		transpose(a,rows,col);
	}
	static void input(int a[][],int rows,int col)
	{
		Scanner sc= new Scanner(System.in);
		int i,j;
		for(i=0;i<rows;i++)
		{
			for(j=0;j<col;j++)
			{
				System.out.print("Enter the element:");
				a[i][j]=sc.nextInt();
			}
		}
		System.out.println("The matrix:");
		for(i=0;i<rows;i++)
		{
			for(j=0;j<col;j++)
				System.out.print(a[i][j]+" ");
			System.out.println();
		}
	}
	static void transpose(int a[][],int rows,int col)
	{
		int b[][]=new int[10][10],i,j,k,l,temp;
		for(i=0,k=0;i<col;i++,k++)
		{
			for(j=0,l=0;j<rows;j++,l++)
			{
				b[i][j]=a[l][k];
			}
		}
		System.out.println("The matrix:");
		for(i=0;i<col;i++)
		{
			for(j=0;j<rows;j++)
				System.out.print(b[i][j]+" ");
			System.out.println();
		}
	}
	
}