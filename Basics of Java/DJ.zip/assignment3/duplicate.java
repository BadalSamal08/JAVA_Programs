import java.util.*;
class duplicate
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int a[]=new int[10],num,i,j;
		System.out.println("Enter the number of elements:");
		num=sc.nextInt();
		for( i=0;i<num;i++)
		{
			System.out.print("Enter the element:");
			a[i]=sc.nextInt();
		}
		for( i=0;i<num;i++)
		{
			for(j=i+1;j<num;j++)
			{
				if(a[i]==a[j])
					System.out.print(a[i]+" ");
			}
		}
	}
}