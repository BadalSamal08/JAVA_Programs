import java.util.*;
class Avg
{
	public static void main(String args[])
	{
		int sum=0;
		Scanner sc =new Scanner(System.in);
		int arr[]=new int[3];
		System.out.println("Enter three numbers:");
		for(int i=0;i<arr.length;i++)
			arr[i]=sc.nextInt();
		for(int i=0;i<arr.length;i++)
			sum=sum+arr[i];
		float avg=(float)sum/3;
		System.out.println("Sum="+sum);
		System.out.println("Average="+avg);
	}
}