import java.util.*;
class Area
{
public static void main(String args[])
{
	int radius;
	double area;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the radius:");
	radius=sc.nextInt();
	area=3.14*(radius*radius);
	System.out.println("Area of the circle:");
	System.out.println(area);
}
}