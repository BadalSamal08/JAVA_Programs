import java.util.*;
class Array
{
public static void main(String args[])
{
	int x[]=new int[4];
Scanner sc=new Scanner(System.in);
for(int i=0;i<x.length;i++)
{
	System.out.println("enter a number:");
	x[i]=sc.nextInt();
}
for(int j=0;j<x.length;j++)
{
	System.out.println(x[j]);
}
}
}