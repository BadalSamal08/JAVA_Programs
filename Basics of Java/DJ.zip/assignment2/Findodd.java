import java.util.*;
class Findodd
{
public static void main(String args[])
{
	int even=0,odd=0;
	int arr[]=new int[10];
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter 10 numbers:");
	for(int i=0;i<arr.length;i++)
	{
		arr[i]=sc.nextInt();
	}
	for(int j=0;j<arr.length;j++)
{
	if(arr[j]%2==0)
		even++;
	else
		odd++;
}
System.out.println("Number of even numbers:"+even);
	System.out.println("Number of odd numbers:"+odd);
}
}