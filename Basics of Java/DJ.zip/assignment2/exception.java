class Test
{
	public static void main( String args[])
	{
		try{
			int a[]=new int[5];
		
		int x=40/0;
		System.out.println(x);
		a[6]=1;
		System.out.println(a[6]);
		}
		
		catch(ArrayIndexOutOfBoundsException f)
		{
			System.out.println(f);
			System.out.println("eend");
		}
		catch(ArithmeticException e)
		{
			System.out.println(e);
			System.out.println("End");
		}
		catch(Exception e)
		{
			System.out.println(e);
			System.out.println("Final");
		}
	}
}