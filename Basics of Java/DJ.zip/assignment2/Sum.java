import java.util.*;
class Sum
{
public static void main(String args[])
{
	Scanner sc =new Scanner(System.in);
	int num;
	System.out.println("Enter a number:");
	num=sc.nextInt();
	Sum(num);
}
static void Sum(int num)
{
	int c=0;
	while(num!=0)
	{
	c=c+(num%10);
	num=num/10;
	}
	System.out.println("Sum is="+c);
}
}