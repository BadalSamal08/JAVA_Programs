import java.util.*;
class Search
{
public static void main(String args[])
{
	int arr[]=new int[10],num,c=0;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter 5 numbers");
	for(int i=0;i<5;i++)
	{
		arr[i]=sc.nextInt();
	}
	System.out.println("Enter number you want to search:");
	num=sc.nextInt();
	for(int i=0;i<arr.length;i++)
	{
		if(num==arr[i])
		{
			System.out.println(num+" number found at "+(i+1)+"th place");
		c++;
		}
	}
	if(c==0)
		System.out.println("Not found.");
	
}
}