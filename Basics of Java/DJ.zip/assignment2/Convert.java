import java.util.*;
class Convert
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int secs,hour,mins,sec;
		System.out.println("Enter the time in seconds:");
		secs=sc.nextInt();
		hour=secs/3600;
		mins=(secs%3600)/60;
		sec=(secs%3600)%60;
		System.out.println(hour+"hours"+mins+"minutes"+sec);
		
	}
}