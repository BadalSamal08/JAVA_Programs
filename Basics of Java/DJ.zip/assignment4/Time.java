import java.util.*;
class AddTime
{
	int hour1,hour2,min1,min2,sec1,sec2,hour,min,sec;
	AddTime(int hr1,int hr2,int mins1,int mins2,int secs1,int secs2)
	{
		hour1=hr1;
		hour2=hr2;
		min1=mins1;
		min2=mins2;
		sec1=secs1;
		sec2=secs2;
	}
	void Add()
	{
		if(sec1+sec2 <60)
		{
			sec=sec1+sec2;
			if(min1+min2 <60)
			{
				min=min1+min2;
				hour=(hour1+hour2);
			}
			else
			{
				min=min1+min2;
				hour=hour1+hour2+(min/60);
				min=min%60;
			}
		}
		else{
			if(min1+min2 <60)
			{
				min=min1+min2+((sec1+sec2)/60);
				hour=hour1+hour2;
				sec=(sec1+sec2)%60;
			}
			else{
				
				min=min1+min2+((sec1+sec2)/60);
				hour=hour1+hour2+(min/60);
				min=min%60;
				sec=(sec1+sec2)%60;
			}
		}
	}
	void display(){ System.out.println(hour+" hour "+min+" minutes "+sec); }

	public static void main(String args[])
	{
		AddTime t1= new AddTime(5,4,60,8,22,50);
		t1.Add();
		t1.display();
	}
}