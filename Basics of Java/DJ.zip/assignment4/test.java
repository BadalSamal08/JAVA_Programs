class Student
{
	int roll,mark,cgpa;
	Student()
	{
		roll=0;
		mark=0;
	}
	Student(int r1,int m1)
	{
		roll=r1;
		mark=m1;
	}
	Student calc()
	{
		Student s2=new Student();
		s2.roll=roll;
		s2.cgpa=(mark)/10;
		return s2;
	}
	void display()
	{
		System.out.println(roll+" "+cgpa);
	}
	public static void main(String args[])
	{
		Student s1[]=new Student[3];
		Student s2[]=new Student[3];
		for(int i=0;i<3;i++)
		{
			s1[i]=new Student(i+1,99+i);
			s2[i]=s1[i].calc();
			s2[i].display();
		}
			
	}
}
	
	