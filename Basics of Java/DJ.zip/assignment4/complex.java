class complex
{
	double img1,img2,real1,real2,img,real;
	complex( double im1,double im2, double re1, double re2)
	{
		img1=im1;
		img2=im2;
		real1=re1;
		real2=re2;
	}
	void mul()
	{
		real=(real1*real2 - img1*img2);
		img=(real1*img2 + img1*real2);
	}
	void display()
	{
		System.out.println(real+"+"+img+"i");
	}
	
	public static void main(String args[])
	{
		complex c1= new complex(1,2,3,4);
		c1.mul();
		c1.display();
	}
}