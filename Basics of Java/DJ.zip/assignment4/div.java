import java.util.*;
class complexdiv
{
	double img1,img2,real1,real2,img,real;
	complexdiv( double im1,double im2, double re1, double re2)
	{
		img1=im1;
		img2=im2;
		real1=re1;
		real2=re2;
	}
	void div()
	{
		real=(real1*real2 + img1*img2)/(real2*real2+img2*img2);
		img=(real2*img1 - img2*real1)/(real2*real2+img2*img2);
	}
	void display()
	{
		System.out.println(real+"+"+img+"i");
	}
	
	public static void main(String args[])
	{
		complexdiv c1= new complexdiv(0,0,2,-3);
		c1.div();
		c1.display();
	}
}