import java.util.*;
class divmethods
{
	double real,img;
	divmethods(double re,double im)
	{
		real=re;
		img=im;
	}
	void div(divmethods d2)
	{
		
		this.real=(real*d2.real + img*d2.img)/(d2.real*d2.real+d2.img*d2.img);
		this.img=(d2.real*img - d2.img*real)/(d2.real*d2.real+d2.img*d2.img);
		
	}
	void display()
	{
		System.out.println(real+"+"+img+"i");
	}
	
	public static void main(String Args[])
	{
		divmethods d1=new divmethods(1,2);
		divmethods d2=new divmethods(3,4);
		d1.div(d2);
		d1.display();
	}
}
	