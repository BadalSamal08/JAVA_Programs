import java.util.*;
class Account
{
	int accNo;
	double balance,timePeriod;
	static double intInYears=7.5;
	
	Account(int acc,double bal,double time)
	{
		accNo=acc;
		balance=bal;
		timePeriod=time;
	}
	double calculateInterst()
	{
		
		return(intInYears*balance*timePeriod)/100;
	}
	
	void showAccDetails()
	{
		double interest=calculateInterst();
		System.out.println(accNo+"       "+balance+"     "+interest);
	}
	
	static void changeIntRate(double newRate)
	{
		intInYears=newRate;
	}
	
	public static void main(String Args[])
	{
		Scanner sc= new Scanner(System.in);
		Account a1[]=new Account[2];
		int i,acc;
		double bal,time;
		for(i=0;i<2;i++)
		{
			System.out.print("Enter the account number:");
			acc=sc.nextInt();
			System.out.print("Enter the account balance:");
			bal=sc.nextDouble();
			System.out.print("Enter the time period:");
			time=sc.nextDouble();
			a1[i]=new Account(acc,bal,time);
		}
		System.out.println("Account number"+"    "+"Balance"+"     "+"interest amount");
		for(i=0;i<2;i++)
		{
			a1[i].showAccDetails();
		}
		Account.changeIntRate(9.1);
		System.out.println();
		System.out.println("Acc_num"+"    "+"Balance"+"     "+"interest amount");
		for(i=0;i<2;i++)
		{
			a1[i].showAccDetails();
		}
	}
	
}