class Item
{
	String name;
	double price;
	int quantity;
	
	Item(String nm,double pr,int qn)
	{
		name=nm;
		price=pr;
		quantity=qn;
	}
	public String getName()
	{
		return name;
	}
	public double getPrice()
	{
		return price;
	}
	public int getQuantity()
	{
		return quantity;
	}
	public double getValue()
	{
		return quantity*price;
	}
}
class Inventory
{
	public static void main(String args[])
	{
		String item_name;
		double inventory;
		double tot_inventory;
		Item i1= new Item("book",200,3);
		Item i2= new Item("pencil",5,200);
		Item i3= new Item("scissors",30,20);
		System.out.println();
		System.out.println("Item        Inventory        Total Inventory");
		System.out.println();
		System.out.println(i1.getName()+"        "+i1.getValue());
		System.out.println(i2.getName()+"      "+i2.getValue());
		System.out.println(i3.getName()+"    "+i3.getValue());
		System.out.println("                                "+(i1.getValue()+i2.getValue()+i3.getValue()));
	}
}