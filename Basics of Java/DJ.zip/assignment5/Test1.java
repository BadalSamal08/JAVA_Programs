 interface Calculator
{
	void add();
	void sub();
	void mul();
	void div();
}
class DemoCalculator implements Calculator
{
	int op1,op2,op3;
	DemoCalculator(int a,int b)
	{
		op1=a;
		op2=b;
	}
	void add()
	{
		System.out.println(op3=op1+op2);
	}
	void sub()
	{
		System.out.println(op3=op1-op2);
	}
	void mul()
	{
		System.out.println(op3=op1*op2);
	}
	void div()
	{
		System.out.println(op3=op1/op2);
	}
}
class Test1
{
	public static void main(String args[])
	{
		DemoCalculator d1= new DemoCalculator(10,2);
		d1.add();
		d1.sub();
		d1.mul();
		d1.div();
	}
}