import java.util.*;
class Employee
{
	private String empName;
	private String empNo;
	private int dependentCnt;
	
	Employee(String name,String eno,int depcnt)
	{
		empName=name;
		empNo=eno;
		dependentCnt=depcnt;
	}
	void showEmpDetails()
	{
		System.out.println();
		
		System.out.println();
		System.out.println("   "+empNo+"              "+"   "+empName);
	}
	int depCount()
	{
		return dependentCnt;
	}
}
class EmpTest
{
	public static void main(String args[])
	{
		int n,depcnt,temp;
		String name,no;
		Scanner sc= new Scanner(System.in);
		System.out.print("Enter the number of employees:");
		n=sc.nextInt();
		Employee e1[]=new Employee[n];
		for(int i=0;i<n;i++)
		{
			System.out.print("Enter the employee name:");
			name=sc.next();
			System.out.print("Enter the employee number:");
			no=sc.next();
			System.out.print("Enter the dependent count of the employee:");
			depcnt=sc.nextInt();
			e1[i]=new Employee(name,no,depcnt);
		}
		System.out.println("EMPLOYEE NUMBER"+" | "+"EMPLOYEE NAME");
		for(int j=0;j<n;j++)
		{
			temp=e1[j].depCount();
			if(temp>2)
			{
				e1[j].showEmpDetails();
			}
		}
		System.out.println(e1[1].empName);
	}
}