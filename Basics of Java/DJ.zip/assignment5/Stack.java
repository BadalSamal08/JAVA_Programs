import java.util.*;
class Stack
{
	int len,top=-1;
	int arr[]=new int[5];
	Stack(int size)
	{
		len=size-1;
	}
	void push(int ele)
	{
		if(top==len)
			System.out.println("Overflow!!");
		else
		{
			top++;
			arr[top]=ele;
			
		}
	}
	int pop()
	{
		if(top==0)
		{
			System.out.println("Underflow!!");
		return 0;
		}
		else
		{
			return arr[top--];
		}
	}
	void show()
	{
		if(top==0)
			System.out.println("Underflow!!");
		else
		{
			for(int i=0;i<=top;i++)
			{
				System.out.print(arr[i]+" ");
			}
		}
	}
}
class Stackops
{
	public static void main(String Args[])
	{
		Scanner sc=new Scanner(System.in);
		Stack s1[]=new Stack[4];
		int ele,temp;
		int ch;
		for(int i=0;i<4;i++)
		{
			System.out.print("for object "+i);
			System.out.println();
			System.out.print("Enter the size:");
			int len=sc.nextInt();
			s1[i]=new Stack(len);
			do
			{
			System.out.print("Enter a choice:(1)Push (2)Pop (3)Show:");
			int choice=sc.nextInt();
			if(choice==1)
			{
				
			System.out.print("Enter the element to be pushed:");
			ele=sc.nextInt();
			s1[i].push(ele);
			}
			else if(choice==2)
			{
				temp=s1[i].pop();
			System.out.println("popped element is "+temp);
			}
			else if(choice==3)
			{
				s1[i].show();
			}
			System.out.print("Do you want to continue:(1-Yes/2-No):");
			ch=sc.nextInt();
			}while(ch==1);
			
		}
	}
}