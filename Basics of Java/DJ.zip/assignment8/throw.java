class Student
{
	int age;
	Student(int a)
	{
		age=a;
	}
	void testage()
	{
		if(age<20)
			throw new ArithmeticException("Under age");
	}
	public static void main(String args[])
	{
		Student s1= new Student(19);
		try{
			s1.testage();
		}
		catch(ArithmeticException e)
		{
			System.out.println(e.getMessage());
		}
	}
}