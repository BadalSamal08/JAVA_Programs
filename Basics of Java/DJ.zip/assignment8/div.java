import java.util.*;
class Div
{
	int a,b;
	Div(int a,int b)
	{
		this.a=a;
		this.b=b;
	}
	int div()
	{
		if(a-b==0)
		{
			throw new ArithmeticException("Not possible");
		}
		return a/a-b;
	}
	public static void main(String args[])
	{
		
		int a,b;
		Scanner sc=new Scanner(System.in);
		a=sc.nextInt();
		b=sc.nextInt();
		Div d1=new Div(a,b);
		try{
			System.out.println(d1.div());
			
		}
		catch(ArithmeticException e)
		{
			System.out.println(e);
		}
	}
}