class minage extends Exception{
	minage(String str)
	{
		super(str);
	}
}
class Student 
{
	int age;
	Student(int ag)
	{
		age=ag;
	}
	void checkage() throws minage
	{
		if(age<20)
			throw new minage("below age");
	}
	public static void main(String args[])
	{
		Student s1=new Student(18);
		try
		{
			s1.checkage();
		}
		catch(minage e)
		{
			System.out.println(e);
		}
	}
}