class MinimumBalanceException extends Exception
{
	MinimumBalanceException(String str)
	{
		super(str);
	}
}
class Account
{
	String name;
	int acc_no;
	double balance;
	double inbalance;
	double depbalance;
	double withbalance;
	double tbalance;
	Account(String nm,int num,double bal)
	{
		name=nm;
		acc_no=num;
		balance=bal;
		inbalance=balance;
		withbalance=bal;
		tbalance=bal;
	}
	void deposit(double amt)
	{
		balance=balance+amt;
		depbalance=balance;
	}
	void withdraw(double amt) throws MinimumBalanceException
	{
		if((balance-amt)<500)
			throw new MinimumBalanceException("Not ennough Balance!!");
		else
		{
			System.out.println("Successful");
			balance=balance-amt;
			withbalance=balance;
		}
	}
	void transfer(Account a1,Account a2,double amt) throws MinimumBalanceException
	{
		if((a1.balance-amt)<500)
			throw new MinimumBalanceException("Not ennough Balance!!");
		else
		{
			System.out.println("Successful");
			a1.balance-=amt;
			a2.balance+=amt;
			a1.tbalance=a1.balance;
			a2.tbalance=a2.balance;;
		}
			
	}
	String tostring()
	{
		return ("   "+acc_no+"        "+inbalance+"     "+depbalance+"    "+tbalance+"    "+withbalance);
	}
	public static void main(String args[])
	{
		Account a1=new Account("Dharmaraj",1123,550);
		Account a2=new Account("Charan",1124,650);
		try
		{
			a1.deposit(200);
			a1.transfer(a1,a2,200);
			a2.withdraw(200);
			
		}
		catch(MinimumBalanceException e)
		{
			System.out.println(e);
		}
		finally
		{
			System.out.println("Account_Number Initial_balance After_deposit After_Transfer After_withdraw ");
			System.out.println(a1.tostring());
			System.out.println(a2.tostring());
		}
	}
}